//Geometrically simplest detector, a cylinder oriented along the beam axis. This one is a water cherenkov detector. 
PyObject* cylindrical_water_py(PyObject *self, PyObject *args);