
/*A very basic model. Takes in a bunch size, and applies the MINERvA experimental event rate (0.81 per 2.25e13 POT). Returns the number of detected neutrinos*/
PyObject *simple_minerva_py(PyObject *self, PyObject *args);
