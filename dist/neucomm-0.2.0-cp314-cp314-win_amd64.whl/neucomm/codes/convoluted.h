#include "codes.h"
#ifndef CONVOLUTED_H
#define CONVOLUTED_H

PyObject* encode_convolution(PyObject *self, PyObject *args);
PyObject* decode_convolution(PyObject *self, PyObject *args);
#endif 