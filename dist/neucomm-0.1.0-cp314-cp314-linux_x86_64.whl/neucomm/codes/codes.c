#include "codes.h"
/*-------------------*/
/* Utility Functions */
/*-------------------*/

//Shift a byte and a bit to the end
inline u8 shift_in(u8 x, u8 bit){
    return (x << 1) | (bit & 1);
}

//Calculate the parity of a byte:
inline u8 parity(u8 x){
    return __builtin_parity(x);
}

//Calculate the hamming distance of two bytes:
inline int hamming(u8 a, u8 b){
    return __builtin_popcount(a ^ b);
}

/*Convert array of bits to ASCII characters
returns newly allocated string*/
char *bits_to_string(const u8 *bits, size_t T) {
    size_t str_len = T / 8;
    char *str = malloc(str_len + 1);
    if (!str) return NULL;
    
    for (size_t i = 0; i < str_len; i++) {
        u8 byte = 0;
        for (int b = 0; b < 8; b++) {
            byte = (byte << 1) | bits[i * 8 + b];
        }
        str[i] = byte;
    }
    str[str_len] = '\0';
    
    return str;
}
/*defo a better way to do this*/

//Takes in a python list of binary, and returns a c array of bytes. allocates the array bytes, and expects the user to deallocate
u8 *py_bin_to_byte(PyObject* list, size_t list_size, size_t* bytes_size) {
    if(list_size % 8 != 0){
        printf("Warning: The number of bits are not divisable by 8. This is undefined behaviour\n");
    }

    *bytes_size = list_size/8;
    u8* bytes = (u8*)calloc(*bytes_size, sizeof(u8));
    size_t i, j;
    for(i = 0; i < *bytes_size; i++){
        for(j = 0; j < 8; j++){
            bytes[i] = shift_in(bytes[i], (u8)PyLong_AsLong(PyList_GetItem(list, (8*i) + j)));
        }
    }
    return bytes;
}

//The inverse of the above function, 
//takes a c array of bytes, and returns a python list
PyObject* byte_to_py_bin(u8* bytes, size_t bytes_size, size_t* list_size){
    *list_size = bytes_size*8;
    PyObject* list = PyList_New(*list_size);

    size_t i;
    int j;
    for(i = 0; i < bytes_size; i++){
        for(j = 7; j>=0; j--){
            PyObject *val = Py_BuildValue("i", (bytes[i] & (1 << j)? 1 : 0));
            PyList_SET_ITEM(list, (8*i) + (7-j), val);
        }
    }   
    return list;
}