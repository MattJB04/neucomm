#include <Python.h>

PyObject* encode_convolution(PyObject *self, PyObject *args);
PyObject* decode_convolution(PyObject *self, PyObject *args);