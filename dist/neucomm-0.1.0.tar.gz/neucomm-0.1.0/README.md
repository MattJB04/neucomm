# neucomm
Python libraries for a neutrino communication project I'm doing


**Note:** This is partly a learning exercise for me, so expect things to be a little rough